import mumpce as mumpce
import mumpce.cantera_utils as mpct
import numpy as np
import pandas as pd

filename = 'Example_measurements.xlsx'
df_dict = pd.read_excel(filename,sheet_name=None)

measurements = dict()

for key in df_dict:
    print(key)
    df = df_dict[key]
    measurements[key] = mpct.measurement_initialize_pd(df)

print(measurements['Flame speeds'][0])