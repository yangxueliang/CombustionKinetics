### mumpce init script
import sys
import os

sys.path.append(os.path.dirname(__file__))

from Project import *
from measurement import tqfunc
#from response_surface import response_surface
#from solution import solution